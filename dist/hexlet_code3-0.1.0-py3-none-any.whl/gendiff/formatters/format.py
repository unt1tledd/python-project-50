from formatters.stylish import format_stylish
from format.plain import format_plain


FORMATS = ['stylish', 'plain']


def choosing_format(format, diff):
    
