# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendif:main']}

setup_kwargs = {
    'name': 'hexlet-code3',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/unt1tledd/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/unt1tledd/python-project-50/actions)# python-project-50\n',
    'author': 'Софья Григорович',
    'author_email': 'sonyashkin@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
